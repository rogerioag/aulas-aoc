void p4a_wrapper_main(int i, float *a, float *b, int n)
{
   // To be assigned to a call to P4A_vp_0: i
   p4a_kernel_main(i, a, b, n);
   ;
}
