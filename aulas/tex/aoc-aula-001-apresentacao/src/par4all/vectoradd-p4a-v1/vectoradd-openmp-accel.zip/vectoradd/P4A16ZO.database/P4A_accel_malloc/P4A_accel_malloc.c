# 2985
void P4A_accel_malloc(void **address, size_t size) { 
  *address = malloc(size); 
}
