void p4a_wrapper_main_1(int i, float *a, float *b, float *c, int n)
{
   // To be assigned to a call to P4A_vp_0: i
   p4a_kernel_main_1(i, a, b, c, n);
   ;
}
