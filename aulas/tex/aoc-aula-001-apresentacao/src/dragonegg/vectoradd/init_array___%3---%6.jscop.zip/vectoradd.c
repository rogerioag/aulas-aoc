#include <stdio.h>
#include <stdlib.h>

/* Default problem size. */
// Size of vectors.
#ifndef N
#  define N 32768
#endif
// Host input vectors.
float h_a[N];
float h_b[N];
// Host output vector.
float h_c[N];

void init_array() {
  fprintf(stdout, "Initialize vectors on host:\n");
	int i;
	// Initialize vectors on host.
	for (i = 0; i < N; i++) {
		h_a[i] = 0.5;
		h_b[i] = 0.5;
	}
}

void print_array() {
  int i;
  fprintf(stdout, "Printing the vector result:\n");
	for (i = 0; i < N; i++) {
		fprintf(stdout, "h_c[%d]: %f\n", i, h_c[i]);
	}
}

void check_result(){
  // Sum up vector c and print result divided by n, this should equal 1 within error
  int i;
	float sum = 0;
	for (i = 0; i < N; i++) {
		sum += h_c[i];
	}
	fprintf(stdout, "Final Result: (%f, %f)\n", sum, (float)(sum / (float)N));
}

int main() {
    int i;

    // Size, in bytes, of each vector
    // size_t bytes = N * sizeof(float);

    // fprintf(stdout, "Allocate memory for each vector on host:\n");
    // Allocate memory for each vector on host
    // h_a = (float *)malloc(bytes);
    // h_b = (float *)malloc(bytes);
    // h_c = (float *)malloc(bytes);

    init_array();

    fprintf(stdout, "Computations:\n");
    // Sum component wise and save result into vector c
    for (i = 0; i < N; i++) {
      h_c[i] = h_a[i] + h_b[i];
    }

#ifdef TEST
    print_array();
#endif
    check_result();

    // Release host memory.
    // free(h_a);
    // free(h_b);
    // free(h_c);

    return 0;
}
