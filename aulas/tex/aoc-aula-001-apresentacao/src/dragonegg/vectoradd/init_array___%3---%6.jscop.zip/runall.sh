#!/bin/sh -a

export PATH_TO_LLVM_BUILD="/dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/"

echo "--> 1. Create LLVM-IR from C"
${PATH_TO_LLVM_BUILD}/bin/clang -S -emit-llvm vectoradd.c -o vectoradd.ll
#/dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/clang -S -emit-llvm vectoradd.c -o vectoradd.ll

echo "--> 2. Load Polly automatically when calling the 'opt' tool"
export PATH_TO_POLLY_LIB="/dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/"

alias opt="${PATH_TO_LLVM_BUILD}/bin/opt -load ${PATH_TO_POLLY_LIB}/LLVMPolly.so"

#/dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so

# /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so -basicaa -polly-import-jscop -polly-import-jscop-postfix=interchanged+tiled+vector -polly-codegen vectoradd.preopt.ll -polly-vectorizer=polly -enable-polly-openmp | /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so -O3 -S > vectoradd.polly.interchanged+tiled+vector+openmp.ll



echo "--> 3. Prepare the LLVM-IR for Polly"
opt -S -mem2reg -loop-simplify -polly-indvars vectoradd.ll > vectoradd.preopt.ll

# /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so -S -mem2reg -loop-simplify -polly-indvars vectoradd.ll > vectoradd.preopt.ll

echo "--> 4. Show the SCoPs detected by Polly"
opt -basicaa -polly-cloog -analyze -q vectoradd.preopt.ll

# /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so -basicaa -polly-cloog -analyze -q vectoradd.preopt.ll

echo "--> 5.1 Highlight the detected SCoPs in the CFGs of the program"
# We only create .dot files, as directly -view-scops directly calls graphviz
# which would require user interaction to continue the script.
# opt -basicaa -view-scops -disable-output vectoradd.preopt.ll
opt -basicaa -dot-scops -disable-output vectoradd.preopt.ll

# /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/bin/opt -load /dados/rogerio/USP/doutorado/prototipo-34-gpu/llvm_build/lib/LLVMPolly.so -basicaa -dot-scops -disable-output vectoradd.preopt.ll

echo "--> 5.2 Highlight the detected SCoPs in the CFGs of the program (print \
no instructions)"
# We only create .dot files, as directly -view-scops-only directly calls
# graphviz which would require user interaction to continue the script.
# opt -basicaa -view-scops-only -disable-output vectoradd.preopt.ll
opt -basicaa -dot-scops-only -disable-output vectoradd.preopt.ll

echo "--> 5.3 Create .png files from the .dot files"
for i in `ls *.dot`; do dot -Tpng $i > $i.png; done

echo "--> 6. View the polyhedral representation of the SCoPs"
opt -basicaa -polly-scops -analyze vectoradd.preopt.ll

echo "--> 7. Show the dependences for the SCoPs"
opt -basicaa -polly-dependences -analyze vectoradd.preopt.ll

echo "--> 8. Export jscop files"
opt -basicaa -polly-export-jscop vectoradd.preopt.ll

echo "--> 9. Import the updated jscop files and print the new SCoPs. (optional)"
opt -basicaa -polly-import-jscop -polly-cloog -analyze vectoradd.preopt.ll
opt -basicaa -polly-import-jscop -polly-cloog -analyze vectoradd.preopt.ll \
    -polly-import-jscop-postfix=interchanged
opt -basicaa -polly-import-jscop -polly-cloog -analyze vectoradd.preopt.ll \
    -polly-import-jscop-postfix=interchanged+tiled
opt -basicaa -polly-import-jscop -polly-cloog -analyze vectoradd.preopt.ll \
    -polly-import-jscop-postfix=interchanged+tiled+vector

echo "--> 10. Codegenerate the SCoPs"
opt -basicaa -polly-import-jscop -polly-import-jscop-postfix=interchanged \
    -polly-codegen \
    vectoradd.preopt.ll | opt -O3 > vectoradd.polly.interchanged.ll
opt -basicaa -polly-import-jscop \
    -polly-import-jscop-postfix=interchanged+tiled -polly-codegen \
    vectoradd.preopt.ll | opt -O3 > vectoradd.polly.interchanged+tiled.ll
opt -basicaa -polly-import-jscop \
    -polly-import-jscop-postfix=interchanged+tiled+vector -polly-codegen \
    vectoradd.preopt.ll -polly-vectorizer=polly\
    | opt -O3 > vectoradd.polly.interchanged+tiled+vector.ll
opt -basicaa -polly-import-jscop \
    -polly-import-jscop-postfix=interchanged+tiled+vector -polly-codegen \
    vectoradd.preopt.ll -polly-vectorizer=polly -enable-polly-openmp\
    | opt -O3 > vectoradd.polly.interchanged+tiled+vector+openmp.ll
opt vectoradd.preopt.ll | opt -O3 > vectoradd.normalopt.ll

echo "--> 11. Create the executables"
llc vectoradd.polly.interchanged.ll -o vectoradd.polly.interchanged.s && gcc vectoradd.polly.interchanged.s \
    -o vectoradd.polly.interchanged.exe
llc vectoradd.polly.interchanged+tiled.ll -o vectoradd.polly.interchanged+tiled.s && gcc vectoradd.polly.interchanged+tiled.s \
    -o vectoradd.polly.interchanged+tiled.exe
llc vectoradd.polly.interchanged+tiled+vector.ll \
    -o vectoradd.polly.interchanged+tiled+vector.s \
    && gcc vectoradd.polly.interchanged+tiled+vector.s \
    -o vectoradd.polly.interchanged+tiled+vector.exe
llc vectoradd.polly.interchanged+tiled+vector+openmp.ll \
    -o vectoradd.polly.interchanged+tiled+vector+openmp.s \
    && gcc -lgomp vectoradd.polly.interchanged+tiled+vector+openmp.s \
    -o vectoradd.polly.interchanged+tiled+vector+openmp.exe
llc vectoradd.normalopt.ll -o vectoradd.normalopt.s && gcc vectoradd.normalopt.s \
    -o vectoradd.normalopt.exe

echo "--> 12. Compare the runtime of the executables"

echo "time ./vectoradd.normalopt.exe"
time -f "%E real, %U user, %S sys" ./vectoradd.normalopt.exe
echo "time ./vectoradd.polly.interchanged.exe"
time -f "%E real, %U user, %S sys" ./vectoradd.polly.interchanged.exe
echo "time ./vectoradd.polly.interchanged+tiled.exe"
time -f "%E real, %U user, %S sys" ./vectoradd.polly.interchanged+tiled.exe
echo "time ./vectoradd.polly.interchanged+tiled+vector.exe"
time -f "%E real, %U user, %S sys" ./vectoradd.polly.interchanged+tiled+vector.exe
echo "time ./vectoradd.polly.interchanged+tiled+vector+openmp.exe"
time -f "%E real, %U user, %S sys" ./vectoradd.polly.interchanged+tiled+vector+openmp.exe
